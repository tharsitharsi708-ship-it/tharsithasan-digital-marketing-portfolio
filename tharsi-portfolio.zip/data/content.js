// All portfolio copy lives here. Edit this file to update the site.
export const profile = {
  name: "Tharsi Thasan",
  title: "Digital Marketing Executive",
  positioning: "Paid social, Google Ads and SEO for healthcare, real estate and education brands.",
  location: "Dubai, UAE",
  email: "tharsitharsi708@gmail.com",
  phone: "+971 52 139 8061",
  linkedin: "https://www.linkedin.com/in/tharsithasan",
  site: "tharsi.xyz",
  seeking: ["Digital Marketing Executive", "SEO Executive", "Social Media Executive", "Digital Marketing Assistant"],
  about: [
    "I'm a B.Com graduate and digital marketer based in Dubai. Through two internships I ran live Meta Ads and Google Ads campaigns, supported SEO and SEM work, and created social content for clients in healthcare, real estate, education and business services.",
    "My day-to-day strengths are keyword and competitor research, audience targeting, campaign monitoring and building creatives in Canva and Figma. I'm looking for a UAE team where I can keep learning from experienced marketers and take on more campaign ownership.",
  ],
  languages: ["English", "Tamil", "Malayalam"],
};

export const work = [
  { client: "Shajini Medical Centre", sector: "Healthcare", channel: "Meta Ads (Facebook and Instagram)",
    did: ["Ran live Meta Ads campaigns, handling audience targeting and performance monitoring.", "Reviewed campaign results and suggested optimisations to improve reach, engagement and enquiries."],
    tools: ["Meta Business Suite", "Facebook Ads", "Instagram Ads"] },
  { client: "Foreway Realtors", sector: "Real estate", channel: "Google Ads",
    did: ["Supported Google Ads campaigns, including audience targeting and performance monitoring.", "Tracked results and passed optimisation suggestions to the marketing team."],
    tools: ["Google Ads", "Google Analytics"] },
  { client: "Unigrant Institute and Hayyan Group", sector: "Education and business services", channel: "SEO and SEM",
    did: ["Carried out keyword research, competitor analysis and market research.", "Supported SEO and SEM campaign planning for both clients."],
    tools: ["Semrush", "Google Search Console", "Google Analytics"] },
  { client: "Physiotherapy centre", sector: "Healthcare", channel: "Facebook Ads and social content",
    did: ["Managed Facebook Ads campaigns to raise online reach, engagement and awareness.", "Designed posters and social creatives in Figma and Canva, and planned and scheduled Facebook and Instagram content."],
    tools: ["Facebook Ads", "Figma", "Canva", "Meta Business Suite"] },
];

export const experience = [
  { role: "Digital Marketing Intern", org: "Infocuz Technologies", place: "Thoothoor, India", dates: "Jan 2026 – Feb 2026",
    points: ["Managed Facebook Ads for a physiotherapy centre to grow reach, engagement and awareness.", "Designed posters and social media creatives in Figma and Canva.", "Planned and scheduled Facebook and Instagram content.", "Supported campaign planning and promotions with the marketing team."] },
  { role: "Digital Marketing Intern", org: "Bluepin DigitalX", place: "Trivandrum, India", dates: "Oct 2025 – Dec 2025",
    points: ["Ran live Meta Ads for Shajini Medical Centre and Google Ads for Foreway Realtors.", "Supported SEO and SEM for Hayyan Group and Unigrant Institute: keyword, competitor and market research.", "Monitored campaign results and suggested optimisations.", "Created and scheduled social content aligned with brand goals."] },
];

export const skills = [
  { group: "Paid media", items: ["Google Ads", "Meta Ads", "Facebook and Instagram Advertising", "Audience Targeting", "Campaign Planning"] },
  { group: "SEO and research", items: ["On-page SEO", "Local SEO", "SEM", "Keyword Research", "Competitor Analysis"] },
  { group: "Content and social", items: ["Social Media Management", "Content Marketing", "Content Scheduling"] },
  { group: "Analytics and reporting", items: ["Google Analytics", "Google Search Console", "Semrush", "Performance Tracking", "Campaign Reporting"] },
  { group: "Tools", items: ["HubSpot", "Meta Business Suite", "Canva", "Figma"] },
];

export const credentials = {
  education: { degree: "Bachelor of Commerce (B.Com)", school: "Teresa Arts and Science College, affiliated to Manonmaniam Sundaranar University", dates: "2022 – 2025" },
  certs: [{ name: "Certified Digital Marketing Specialist (CDMS)", by: "DigitalX Academy, 2025" }, { name: "LinkedIn Advertising Fundamentals Certification", by: "LinkedIn" }],
};
