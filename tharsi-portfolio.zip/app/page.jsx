import Header from "@/components/Header";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Work from "@/components/Work";
import Experience from "@/components/Experience";
import Skills from "@/components/Skills";
import Credentials from "@/components/Credentials";
import Contact from "@/components/Contact";
import { profile, work, experience, skills, credentials } from "@/data/content";

export default function Home() {
  return (
    <>
      <Header name={profile.name} />
      <main>
        <Hero p={profile} />
        <About p={profile} />
        <Work items={work} />
        <Experience items={experience} />
        <Skills groups={skills} />
        <Credentials c={credentials} />
        <Contact p={profile} />
      </main>
      <footer className="mx-auto max-w-5xl px-5 py-10 text-sm text-muted sm:px-8">© {new Date().getFullYear()} {profile.name} · {profile.location}</footer>
    </>
  );
}
