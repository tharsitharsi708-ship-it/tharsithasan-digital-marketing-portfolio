import ThemeToggle from "./ThemeToggle";
const links = [["Work", "#work"], ["Experience", "#experience"], ["Skills", "#skills"], ["Contact", "#contact"]];

export default function Header({ name }) {
  return (
    <header className="sticky top-0 z-10 border-b border-line bg-bg/85 backdrop-blur">
      <nav className="mx-auto flex max-w-5xl items-center justify-between px-5 py-3 sm:px-8" aria-label="Main">
        <a href="#top" className="font-display font-semibold">{name}</a>
        <div className="flex items-center gap-5 text-sm">
          <ul className="hidden gap-5 sm:flex">
            {links.map(([l, h]) => (<li key={h}><a href={h} className="text-muted transition-colors hover:text-ink">{l}</a></li>))}
          </ul>
          <ThemeToggle />
        </div>
      </nav>
    </header>
  );
}
