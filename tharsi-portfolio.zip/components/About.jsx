import Section from "./Section";
export default function About({ p }) {
  return (
    <Section id="about" title="About">
      <div className="grid gap-10 md:grid-cols-[3fr_2fr]">
        <div className="max-w-prose space-y-4 text-lg leading-relaxed">{p.about.map((t) => <p key={t}>{t}</p>)}</div>
        <dl className="space-y-4 text-sm">
          <div><dt className="text-muted">Open to</dt><dd className="mt-1">{p.seeking.join(", ")}</dd></div>
          <div><dt className="text-muted">Languages</dt><dd className="mt-1">{p.languages.join(", ")}</dd></div>
          <div><dt className="text-muted">Based in</dt><dd className="mt-1">{p.location}</dd></div>
        </dl>
      </div>
    </Section>
  );
}
