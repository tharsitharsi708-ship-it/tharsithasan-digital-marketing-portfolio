import Section from "./Section";
export default function Credentials({ c }) {
  return (
    <Section id="credentials" title="Education and certifications">
      <div className="grid gap-8 md:grid-cols-2">
        <div>
          <h3 className="font-display text-lg font-semibold">{c.education.degree}</h3>
          <p className="mt-1 text-muted">{c.education.school}</p>
          <p className="mt-1 text-sm text-muted">{c.education.dates}</p>
        </div>
        <ul className="space-y-4">
          {c.certs.map((x) => (<li key={x.name}><p className="font-medium">{x.name}</p><p className="text-sm text-muted">{x.by}</p></li>))}
        </ul>
      </div>
    </Section>
  );
}
