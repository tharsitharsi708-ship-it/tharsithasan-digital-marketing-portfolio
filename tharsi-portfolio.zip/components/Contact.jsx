import Section from "./Section";
export default function Contact({ p }) {
  const rows = [["Email", p.email, `mailto:${p.email}`], ["Phone", p.phone, `tel:${p.phone.replace(/\s/g, "")}`], ["LinkedIn", "linkedin.com/in/tharsithasan", p.linkedin]];
  return (
    <Section id="contact" title="Let's talk">
      <p className="max-w-prose text-lg">I'm looking for a digital marketing, SEO or social media role in the UAE. The quickest way to reach me is email.</p>
      <ul className="mt-6 divide-y divide-line border-y border-line">
        {rows.map(([l, v, h]) => (
          <li key={l} className="grid gap-1 py-4 sm:grid-cols-[140px_1fr]">
            <span className="text-muted">{l}</span>
            <a href={h} className="font-medium text-link hover:underline">{v}</a>
          </li>
        ))}
      </ul>
    </Section>
  );
}
