import Section from "./Section";
export default function Work({ items }) {
  return (
    <Section id="work" title="Client work">
      <div className="grid gap-5 md:grid-cols-2">
        {items.map((w) => (
          <article key={w.client} className="rounded-xl border border-line bg-surface p-6 transition-colors hover:border-ink/40">
            <p className="text-sm text-muted">{w.sector}</p>
            <h3 className="mt-1 font-display text-xl font-semibold">{w.client}</h3>
            <p className="mt-1 text-sm font-medium text-accent">{w.channel}</p>
            <ul className="mt-4 list-disc space-y-2 pl-5 text-[15px] leading-relaxed">{w.did.map((d) => <li key={d}>{d}</li>)}</ul>
            <ul className="mt-5 flex flex-wrap gap-2">
              {w.tools.map((t) => <li key={t} className="rounded-md bg-bg px-2.5 py-1 text-xs text-muted">{t}</li>)}
            </ul>
          </article>
        ))}
      </div>
    </Section>
  );
}
