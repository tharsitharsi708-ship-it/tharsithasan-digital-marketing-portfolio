import Section from "./Section";
export default function Skills({ groups }) {
  return (
    <Section id="skills" title="Skills">
      <dl className="divide-y divide-line border-y border-line">
        {groups.map((g) => (
          <div key={g.group} className="grid gap-2 py-4 sm:grid-cols-[200px_1fr]">
            <dt className="font-medium">{g.group}</dt>
            <dd className="text-muted">{g.items.join(", ")}</dd>
          </div>
        ))}
      </dl>
    </Section>
  );
}
