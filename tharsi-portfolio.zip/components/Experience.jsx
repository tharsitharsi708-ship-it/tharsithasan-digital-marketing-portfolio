import Section from "./Section";
export default function Experience({ items }) {
  return (
    <Section id="experience" title="Experience">
      <ol className="space-y-10 border-l border-line pl-6 sm:pl-8">
        {items.map((e) => (
          <li key={e.org} className="relative">
            <span className="absolute -left-[31px] top-2 h-2.5 w-2.5 rounded-full bg-accent sm:-left-[39px]" aria-hidden />
            <p className="text-sm text-muted">{e.dates} · {e.place}</p>
            <h3 className="mt-1 font-display text-xl font-semibold">{e.role}, {e.org}</h3>
            <ul className="mt-3 list-disc space-y-1.5 pl-5 leading-relaxed">{e.points.map((x) => <li key={x}>{x}</li>)}</ul>
          </li>
        ))}
      </ol>
    </Section>
  );
}
