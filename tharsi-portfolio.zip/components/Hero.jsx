// The hero is a search result for the candidate: the thing her work is meant to win.
export default function Hero({ p }) {
  return (
    <section id="top" className="mx-auto max-w-5xl px-5 pb-12 pt-14 sm:px-8 sm:pt-24">
      <p className="text-muted">Digital marketing portfolio · {p.location}</p>
      <h1 className="mt-3 max-w-3xl font-display text-5xl font-semibold leading-[1.05] tracking-tight sm:text-7xl">{p.name}</h1>
      <p className="mt-5 max-w-2xl text-lg text-muted sm:text-xl">{p.positioning}</p>

      <div className="serp mt-10 max-w-2xl rounded-xl border border-line bg-surface p-5 sm:p-6" aria-label="Search result preview">
        <p className="truncate text-sm text-muted">{p.site} › {p.title.toLowerCase().replace(/ /g, "-")}</p>
        <p className="mt-1 font-display text-xl text-link sm:text-2xl">{p.name} – {p.title} | SEO, SEM and Paid Social</p>
        <p className="mt-1.5 text-[15px] leading-relaxed text-muted">
          Google Ads, Meta Ads and SEO experience across healthcare, real estate and education clients. Based in Dubai and open to roles across the UAE.
        </p>
        <ul className="mt-4 flex flex-wrap gap-x-5 gap-y-1 border-t border-line pt-3 text-sm">
          {[["Work", "#work"], ["Experience", "#experience"], ["Skills", "#skills"], ["Contact", "#contact"]].map(([l, h]) => (
            <li key={h}><a href={h} className="text-link hover:underline">{l}</a></li>
          ))}
        </ul>
      </div>

      <div className="mt-8 flex flex-wrap gap-3">
        <a href={`mailto:${p.email}`} className="rounded-lg bg-ink px-5 py-3 font-medium text-bg transition-opacity hover:opacity-85">Email Tharsi</a>
        <a href={p.linkedin} target="_blank" rel="noreferrer" className="rounded-lg border border-line px-5 py-3 font-medium transition-colors hover:border-ink">View LinkedIn</a>
      </div>
    </section>
  );
}
